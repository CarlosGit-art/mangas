<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mangas online</title>
    <link rel="stylesheet" href="../css/manga.css">
</head>
<body>
    <header>
    <img src='../imagenes/fire.png' id='logo'>
    </header>
    <nav>
        <?php
         session_start();
         //usamos el sesion start y pedimos el nombredel usuario
         if (!isset($_SESSION['nombre_usuario'])){
             echo '
             <!-- iniciamos o creamos una sesion -->
             <a href="iniciosesion.php">Ingresar</a>
             <a href="crearsesion.php">Crear cuenta</a>';
         } else{
             echo '<a href="cerrarSesion.php">Cerrar sesión</a>';
             //cerramos  una  sesion
             if(isset($_SESSION['carrito'])){
                echo '<a href="carritomanga.php"> Mi manga</a>';
                //mostramos  el boton del carrito manga
                }
            }

         if(isset($_SESSION['nombre_usuario'])){
          echo '
        <div class="dropdown">
            <form action="guardarreserva.php" method="get" id="deslizante">
                <select name="categoria" id="mangas" onchange="this.form.submit()">
                    <option name="categoria" value="">mangas</option>
                    <option name="categoria" value="accion">accion</option>
                    <option name="categoria" value="romance">romance</option>
                    <option name="categoria" value="shonen">shonen</option>
                    <option name="categoria" value="terror">terror</option>
                </select>
            </form>
        </div>';
            if($_SESSION['tipo_usuario']==1){
                // creamos un manga en caso de ser admin
                echo' <a href="crearmanga.php">crear manga</a>';
               }

            }
        ?>
    </nav>
    <main>
       
        </main>
            <?php
            require ("footer.php");
        ?>
 
</body>
</html>
