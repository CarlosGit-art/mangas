<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
</head>
<link rel="stylesheet" href="../css/estilos.css">
<link rel="stylesheet" href="../css/mangas.css">
<body>
<nav>
        <?php
        session_start();
if (!isset($_SESSION['nombre_usuario'])){
             echo '<a href="iniciosesion.php">Ingresar</a>
             <a href="crearsesion.php">Crear cuenta</a>';
         }else{
             echo '<a href="cerrarSesion.php">Cerrar sesión</a>';
             if(isset($_SESSION['carrito'])){
                echo '<a href="carritomanga.php"> Mi manga</a>';
                }
         }

        if(isset($_SESSION['nombre_usuario'])){
          echo '
                <div class="dropdown">
                    <form action="guardarreserva.php" method="get">
                      <select name="categoria" id="mangas" onchange="this.form.submit()">
                    <option name="categoria" value="">mangas</option>
                    <option name="categoria" value="accion">accion</option>
                    <option name="categoria" value="romance">romance</option>
                    <option name="categoria" value="shonen">shonen</option>
                    <option name="categoria" value="terror">terror</option>
                     </select>
                    </form>
                </div>';
            if($_SESSION['tipo_usuario']==1){
                echo' <a href="crearmanga.php">crear mangas</a>';
            }
        }
        ?>
    </nav>
<?php
        include('../sql/conexion.php');
// Obtener  desde la URL
$categoria_seleccionada = isset($_GET['categoria']) ? $_GET['categoria'] : '';

// Consulta SQL para obtener productos de la categoría seleccionada
$sql = "SELECT * FROM mangas" . ($categoria_seleccionada ? " WHERE categoria = '$categoria_seleccionada'" : "");
$resultado = mysqli_query($conexion, $sql);
if ($resultado->num_rows > 0) {
    echo '<div class="productos-container">'; // Contenedor para productos
       //si la categoria es igual a la  insertada se hara lo siguiente
    while ($arreglo = $resultado->fetch_assoc()) {
        // Obtener datos del producto y los mostramos en forma de caja  
        echo '<div class="product">';
        echo '<img src="' . $arreglo['imagen'] . '" alt="' . $arreglo['titulo'] . '" class="product-image">';
        echo '<div class="product-details">';
        echo '<p class="product-info"><span>titulo:</span> ' . htmlspecialchars($arreglo["titulo"]) . '</p>';
        echo '<p class="product-info"><span>autor:</span> ' . htmlspecialchars($arreglo["autor"]) . '</p>';
        echo '<p class="product-info"><span>Precio:</span> ' . htmlspecialchars($arreglo['precio']) . '</p>';
        echo '<p class="product-info"><span>Categoría:</span> ' . htmlspecialchars($arreglo['categoria']) . '</p>';
        if ($_SESSION['tipo_usuario'] == 1) {
            //  Si el usuario es administrador, mostrar botón de editar
            echo '<a href="editarmanga.php?id=' . $arreglo['id'] . '">
                    <button class="botons">Editar</button>
                  </a>';
        }
        echo '  <!-- reservar un manga en especifico y te manda al carrito manga-->
                <form action="agregarmanga.php" method="POST" class="add-to-cart-form">
                <label for="cantidad">Cantidad:</label>
                <input min="1" value="1" type="number" name="cantidad">
                <input type="hidden" name="id" value="' . $arreglo["id"] . '">
                <input type="hidden" name="categoria" value="' . $arreglo["categoria"] . '">
                <button type="submit" class="botons">reservar</button>
               </form>';
             
        echo '</div>'; // Cerrar contenedor de detalles
        echo '</div>'; // Cerrar contenedor de producto
    }

    echo '</div>'; // Cerrar contenedor de productos
} else {
    echo '<p class="no-products">Sin productos</p>';
}
?>
<br>
        <?php
            require ("footer.php");
        ?>

    </body>
</html>
