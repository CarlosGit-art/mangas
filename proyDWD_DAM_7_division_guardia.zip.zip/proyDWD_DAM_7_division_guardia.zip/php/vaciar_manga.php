<?php
session_start(); //resumimos la sesion
$_SESSION['carrito'] = array(); //restablecemos el carrito

header("Location: index.php"); //redirigimos a pag principal
?>