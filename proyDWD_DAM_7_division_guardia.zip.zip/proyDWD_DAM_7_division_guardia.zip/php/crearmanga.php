<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mangas online</title>
    <link rel="stylesheet" href="../css/manga.css">
</head>
<body>
    <header>
    <img src='../imagenes/fire.png' id='logo'>
    </header>
    <nav>
        <?php
         session_start();
         if (!isset($_SESSION['nombre_usuario'])){
             echo '
             <a href="iniciosesion.php">Ingresar</a>
             <a href="crearsesion.php">Crear cuenta</a>';
             
         } else{
             echo '<a href="cerrarSesion.php">Cerrar sesión</a>';
             // hacemos una  sesion para el carrito de mangas asi lo  mostramos y usamos
             if(isset($_SESSION['carrito'])){
                echo '<a href="carritomanga.php"> Mi manga</a>';
                }
            }

         if(isset($_SESSION['nombre_usuario'])){
          echo '
        <div class="dropdown">
            <form action="guardarreserva.php" method="get">
                <select name="categoria" id="mangas" onchange="this.form.submit()">
                    <option name="categoria" value="">mangas</option>
                    <option name="categoria" value="accion">accion</option>
                    <option name="categoria" value="romance">romance</option>
                    <option name="categoria" value="shonen">shonen</option>
                    <option name="categoria" value="terror">terror</option>
                </select>
            </form>
        </div>';

            }
        ?>
    </nav>
    <main>
      
         <?php
           
             echo '<a style="border-style: double;">Crear los mangas</a>';
             echo ' <div class="row">
                     <form action="mangas.php" method="post">
                     <input type="text" name="titulo" placeholder="titulo del manga">
                     <br>
                     <input type="text" name="autor" placeholder="autor">
                     <br>
                     <input type="number" name="stock" placeholder="stock">
                     <br>
                    <input type="number" name="precio" placeholder="precio">
                    <br>
                <select name="categoria" id="mangas">
                    <option name="categoria" value="">Seleccione mangas</option>
                    <option name="categoria" value="accion">accion</option>
                    <option name="categoria" value="romance">romance</option>
                    <option name="categoria" value="shonen">shonen</option>
                    <option name="categoria" value="terror">terror</option>
                </select>
                  <input type="file" name="imagen" accept="image/*">
                  <!-- seleccion de una imagen -->
                  <button type="submit">Cargar manga nuevo</button>
                    </form>
               </div>';
             echo '<br>';
       //formulario para crear  un manga en especico
    ?>

        </main>
            <?php
            require ("footer.php");
        ?>
 
</body>
</html>