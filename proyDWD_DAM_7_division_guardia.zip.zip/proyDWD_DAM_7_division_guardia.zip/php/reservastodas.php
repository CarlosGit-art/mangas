<?php
 include('../sql/conexion.php');
 $id = $_POST['id'];
 $usuario = $_POST['usuario_id'];
 $manga = $_POST['manga_id'];
 $cantidad = $_POST['cantidad'];
 $sql = "INSERT INTO mangascomprados (cantidad) VALUES ('".$cantidad."')"; 
 $resultado= mysqli_query($conexion,$sql);
 
 if ($resultado) {
    header("Location:carritomanga.php");
 }else {
   header("Location: index.php");
   echo"user no conectado";
    mysqli_error($conexion);
 }


?>