<?php
 include('../sql/conexion.php');
 $nombre = $_POST['nombre_usuario'];
 $correo= $_POST['email'];
 $contrasenia = $_POST['contrasenia'];
 $contraencriptada = md5($contrasenia);
 //iniciamos una sesion con los datos dela base y la encriptacion de  contraseña 
 $sql = "INSERT INTO usuarios (nombre_usuario,email,contrasenia)
VALUES ('".$nombre."','".$correo."','".$contraencriptada."')"; 
 $resultado= mysqli_query($conexion,$sql);
 
 if ($resultado) {
    header("Location:index.php");
 }else {
   header("Location: index.php");
   echo"user no conectado";
    mysqli_error($conexion);
 }

  ?>