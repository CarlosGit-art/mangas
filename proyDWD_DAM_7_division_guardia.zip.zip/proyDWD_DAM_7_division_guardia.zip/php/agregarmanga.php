
<?php
  include('../sql/conexion.php');

$id = $_POST['id'];
  $cantidad = $_POST['cantidad'];
  $categoria = $_POST['categoria'];
  
  $sql = "SELECT * FROM mangas WHERE id='$id'";
  $resultado = mysqli_query($conexion, $sql);
  $arreglo = mysqli_fetch_assoc($resultado); //producto


// Verificar si hay suficiente stock
if ($arreglo['stock'] >= $cantidad) {
    // Si hay suficiente stock, reducirlo en la base de datos
    $nuevo_stock = $arreglo['stock'] - $cantidad;
    $sql_actualizar_stock = "UPDATE mangas SET stock = '$nuevo_stock' WHERE id = '$id'";
    mysqli_query($conexion, $sql_actualizar_stock);

    // Luego de actualizar el stock, agregamos el producto al carrito como antes
    $datos_producto = array("id" => $arreglo['id'], "titulo" => $arreglo['titulo'], "cantidad" => $cantidad, "precio" => $arreglo['precio']);
    session_start();
    $mi_carrito = $_SESSION['carrito'];
    $producto_existe = false;

    for ($i = 0; $i < count($mi_carrito); $i++) {
        if ($mi_carrito[$i]['id'] == $arreglo['id']) {
            // Si el producto ya está en el carrito, aumentamos la cantidad
            $mi_carrito[$i]['cantidad'] += $cantidad;
            $producto_existe = true;
            break;
        }
    }

    if (!$producto_existe) {
        // Si el producto no está en el carrito, lo agregamos
        array_push($mi_carrito, $datos_producto);
    }

    $_SESSION['carrito'] = $mi_carrito; // Reemplazamos el nuevo valor del carrito
    //tabla intermediaria del pedido entre  el usuario y manga
    // como la hago
    //como armo el pdf del pedido insertamos   y pedimos el id de usuario y el manga y ponemos los
    // datos del manga y armamos ese  pdf
    header("Location: carritomanga.php?categoria=".$categoria);
} else {
          // Si no hay suficiente stock, mostrar un mensaje de error
          //header("index.php");
         echo "<script language='javascript'>
          alert('No hay suficiente stock de ese producto, lamentamos los inconvenientes');
          window.location.href='index.php';
          </script>";
        }
  
?>