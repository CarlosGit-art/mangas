<?php
include('../sql/conexion.php');
$index = $_POST['index'];
session_start(); //resumimos la sesion para traer los datos del carrito
// Obtener la cantidad del producto que se va a eliminar
$manga_eliminado = $_SESSION['carrito'][$index];
$cantidad_eliminada = $producto_eliminado['cantidad'];
$id_producto = $manga_eliminado['id'];

// Restaurar el stock del producto en la base de datos
$sql_obtener_stock = "SELECT stock FROM mangas WHERE id = '$id_producto'";
$resultado_stock = mysqli_query($conexion, $sql_obtener_stock);
$producto_stock = mysqli_fetch_assoc($resultado_stock);
$nuevo_stock = $producto_stock['stock'] + $cantidad_eliminada;

$sql_actualizar_stock = "UPDATE mangas SET stock = '$nuevo_stock' WHERE id = '$id_producto'";
mysqli_query($conexion, $sql_actualizar_stock);

// Luego, eliminar el producto del carrito como antes
if ($index == 0) {
    array_shift($_SESSION['carrito']);
} else {
    array_splice($_SESSION['carrito'], $index, 1);
}

header("Location: index.php");
?>