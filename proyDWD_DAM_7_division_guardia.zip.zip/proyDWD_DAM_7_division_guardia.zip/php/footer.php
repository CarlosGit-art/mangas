<?php

echo "
<footer>
      <!-- footer con todos los datos y links -->
      <div class='informacion'>
        <img src='../imagenes/fire.png' id='logo'>
        <br>
        <p></p>
        <p>Domicilio: Calle 73 Nº 1502- Necochea<br>
          Tel: 2262-362674<br>
          </p>
        <p>Mira mas en nuestras redes!!</p>
        <br>
        <a href='../pdf/ManualDesuario.pdf' target='_blank'>Descargar manual de usuario</a>
        <br>
        <button id='logo_instagram'>
        <a href='https://www.instagram.com/nic0guardia/' target='_blank'><img src='../imagenes/instagramlogo.png' alt='' class='imagen'></a></button>
        <button id='logo_facebook'>
        <a href='https://www.facebook.com/nicolasguardia/' target='_blank'><img src='../imagenes/facebook.png' alt='' class='imagen'> </a></button>
      </div>
    </footer>";

?>