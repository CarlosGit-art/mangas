<?php
include('../sql/conexion.php');

// Recibir los datos del formulario
$id = $_POST['id'];
$titulo = $_POST['titulo'];
$autor= $_POST['autor'];
$stock = $_POST['stock'];
$precio = $_POST['precio'];
$categoria = $_POST['categoria'];
// Ruta de destino para guardar las imágenes
$directorio = "../imagenes/";
$archivoImagen = $directorio . basename($_FILES["imagen"]["name"]);
$tipoArchivo = strtolower(pathinfo($archivoImagen, PATHINFO_EXTENSION));

// Consulta SQL para actualizar el producto sin cambiar la imagen
$sql = "UPDATE mangas SET 
        titulo = '$titulo', 
        autor = '$autor', 
        stock = '$stock', 
        precio = '$precio', 
        categoria = '$categoria' 
        WHERE id = $id";

if (isset($_FILES["imagen"]) && $_FILES["imagen"]["name"] != '') {
    // Si se subió una nueva imagen, primero moverla y luego actualizar la base de datos
    if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $archivoImagen)) {
        $sql = "UPDATE mangas SET 
                 titulo = '".$titulo."', 
                 autor = '".$autor."', 
                 stock = ".$stock.", 
                 precio = ".$precio.", 
                 categoria = '".$categoria."',
                 imagen = '".$archivoImagen."'
                WHERE id = ".$id."";
            echo $sql;
    } else {
        echo "Error al subir la imagen.";
        exit;
    }
}

// Ejecutar la consulta de actualización
$resultado = mysqli_query($conexion, $sql);

if ($resultado) {
    header("Location: index.php"); // Redirigir al índice después de actualizar
} else {
    echo "Error al actualizar el producto: " . mysqli_error($conexion);
}
?>
