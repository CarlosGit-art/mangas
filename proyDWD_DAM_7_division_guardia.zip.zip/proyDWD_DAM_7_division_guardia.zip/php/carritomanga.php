<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
</head>
<link rel="stylesheet" href="../css/manga.css">
<body>
<header>
    <img src='../imagenes/fire.png' id='logo'>
    </header>
<nav>
        <?php
        session_start();
        //iniciamos una sesion con todos los datos del nav
if (!isset($_SESSION['nombre_usuario'])){
             echo '<a href="iniciosesion.php">Ingresar</a>
             <a href="crearsesion.php">Crear cuenta</a>';
         }else{
             echo '<a href="cerrarSesion.php">Cerrar sesión</a>';
             if(isset($_SESSION['carrito'])){
                echo '<a href="carritomanga.php"> Mi manga</a>';
                }
         }

        if(isset($_SESSION['nombre_usuario'])){
          echo '
                <div class="dropdown">
                    <form action="guardarreserva.php" method="get">
                      <select name="categoria" id="mangas" onchange="this.form.submit()">
                    <option name="categoria" value="">mangas</option>
                    <option name="categoria" value="accion">accion</option>
                    <option name="categoria" value="romance">romance</option>
                    <option name="categoria" value="shonen">shonen</option>
                    <option name="categoria" value="terror">terror</option>
                     </select>
                    </form>
                </div>';
            if($_SESSION['tipo_usuario']==1){
                echo' <a href="crearmanga.php">crear mangas</a>';
            }
        }
        ?>
    </nav>
    <?php
        include('../sql/conexion.php');
        if (isset($_SESSION['nombre_usuario'])) { //si el nombre esta seteado en la sesion (si esta logueado)

            //se imprime el carrito y el boton de cerrar sesion
            echo '<a style="border-style: double;">Carrito con mangas</a><br><br>';
            //mostrar el carrito
            $total = 0;
            $limite = count($_SESSION['carrito']); //tomamos la cantidad de productos (limite)

            echo '<div class="productos-container">'; // Contenedor para productos
            for ($i=0; $i < $limite ; $i++) { //recorremos cada producto
                foreach ($_SESSION['carrito'][$i] as $x => $y) { //recorremos cada dato dentro del producto
                    //hacemos la consulta del producto
                    $sql = "SELECT * FROM mangas WHERE id =".$_SESSION['carrito'][$i]['id'];
                    $resultado = mysqli_query($conexion,$sql);
                    $arreglo = mysqli_fetch_assoc($resultado);
                }
                 //mostramos los productos del carrito manga con sus valores y la funcion de borrar uno o todos y de reservarlos
                echo '<div class="product">';  //abrimos una caja para cada  producto asi no se diferencie
                echo '<img src="' . $arreglo['imagen'] . '" alt="' . $arreglo['titulo'] . '" class="image">';
                echo '<div class="product-details">';
                echo '<p class="product-info"><span>titulo:</span> ' . htmlspecialchars($arreglo["titulo"]) . '</p>';
                echo '<p class="product-info"><span>autor:</span> ' . htmlspecialchars($arreglo["autor"]) . '</p>';
                echo '<p class="product-info"><span>Precio:</span> ' . htmlspecialchars($arreglo['precio']) . '</p>';
                echo '<p class="product-info"><span>Categoría:</span> ' . htmlspecialchars($arreglo['categoria']) . '</p>';
                echo '</div>'; // Cerrar contenedor de detalles
                echo '<form action="borrarmanga_item.php" method="post">
                        <input hidden type="number" name="index" value="'.$i.'">
                        <input type="submit" class="botons" value="borrar">
                    </form>';
                echo '<br>';
                echo '</div>'; // Cerrar contenedor de producto
                $precio = intval($_SESSION['carrito'][$i]['precio']); //parseamos el precio en string a int
                $total = $total+$precio;
            //formulario para borrar un item especifico del carrito, usamos un input "hidden" para mandar el indice del producto a borrar
                
            }
            echo '</div>'; // Cerrar contenedor de productos
            echo 'El total del carrito es: $ '.$total;   //total de todo el carrito
            echo '<br>';
            //formulario vaciar manga
            echo '<form action="vaciar_manga.php">
                    <button type="submit" class="botons" >Vaciar manga</button>
                </form>';
            }
              //formulario confirmar  reserva
           echo'<form action="reservastodas.php" method="post">
           <div class="product">
           <input type="hidden" id="id" name="id">
           <input type="hidden" id="usuario_id" name="usuario_id">
           <label for="cantidad">ingresar  cantidad  especifica</label>
               <input type="text" id="cantidad" name="cantidad" required>
               <br>
               <label for="mangas">ingresar el nombre  del manga</label>
               <input type="text" id="manga_id" name="nombre del manga" required>
           </div>
           <div class="form-group">
           <input type="submit" value="Confirmar reserva">
       </div>
           <br>
       </form>';
?>
<br>
<?php
            require ("footer.php");
        ?>
</body>
</html>