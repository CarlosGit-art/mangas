<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<header>
    <img src='../imagenes/fire.png' id='logo'>
    </header>
    <div class="login-container">
        <h2>Iniciar Sesión</h2>
        <form action="inicio.php" method="post">
            
        <input type="hidden" id="id" name="id">
        <input type="hidden" id="email" name="email">

            <label for="username">Nombre de Usuario:</label>
            <input type="text" id="nombre_usuario" name="nombre_usuario" required>
            
            <label for="password">Contraseña:</label>
            <input type="password" id="contrasenia" name="contrasenia" required>
            
            <button type="submit">Iniciar Sesión</button>
        </form>
    </div>
</body>
</html>