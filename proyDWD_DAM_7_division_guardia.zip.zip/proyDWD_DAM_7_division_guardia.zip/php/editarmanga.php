<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edicion de mangas</title>
    <link rel="stylesheet" href="../css/estilos.css">
<link rel="stylesheet" href="../css/mangas.css">
</head>
<body>
    <header>
    <img src='../imagenes/fire.png' id='logo'>
    </header>
<nav>
        <?php
        session_start();
          //pedimos  una sesion y hacemos  un if para ver si existe
if (!isset($_SESSION['nombre_usuario'])){
             echo '<a href="iniciosesion.php">Ingresar</a>
             <a href="crearsesion.php">Crear cuenta</a>';
         }else{
             echo '<a href="cerrarSesion.php">Cerrar sesión</a>';
             if(isset($_SESSION['carrito'])){
             echo '<a href="carritomanga.php"> Mi manga</a>';
             }
         }

        if(isset($_SESSION['nombre_usuario'])){
          echo '
                <div class="dropdown">
                    <form action="guardarreserva.php" method="get">
                      <select name="categoria" id="mangas" onchange="this.form.submit()">
                    <option name="categoria" value="">mangas</option>
                    <option name="categoria" value="accion">accion</option>
                    <option name="categoria" value="romance">romance</option>
                    <option name="categoria" value="shonen">shonen</option>
                    <option name="categoria" value="terror">terror</option>
                     </select>
                    </form>
                </div>';
            if($_SESSION['tipo_usuario']==1){
                 //hacemos un if para ver si existe el usuario admin y si existe mostramos el boton
                echo' <a href="crearproducto.php">crear producto</a>';
            }
        }
        ?>
    </nav>
<?php
include('../sql/conexion.php');

// Obtener el ID del producto que se desea editar
$id = $_GET['id'];

// Obtener los detalles del producto de la base de datos
$sql = "SELECT * FROM mangas WHERE id = $id";
$resultado = mysqli_query($conexion, $sql);
$producto = mysqli_fetch_assoc($resultado);

// Verificar si el producto existe
if (!$producto) {
    echo "Producto no encontrado.";
    exit;
}
?>

<!-- Formulario para editar el producto -->
<form action="actualizarmanga.php" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $producto['id']; ?>">
    <input type="text" name="titulo"  class="datomanga" placeholder="Nombre del manga" value="<?php echo $producto['titulo']; ?>" required>
    <input type="text" name="autor" class="datomanga" placeholder="Autor de este" value="<?php echo $producto['autor']; ?>" required>
    <input type="number" name="stock" class="datomanga" placeholder="Cantidad en stock" value="<?php echo $producto['stock']; ?>" required>
    <input type="number" name="precio" class="datomanga" placeholder="Precio" value="<?php echo $producto['precio']; ?>" required>
    <select name="categoria" class="info-boton" required>
        <option value=""  class="info">Seleccione categoría</option>
        <option value="accion"  class="info"<?php if($producto['categoria'] == 'accion') echo 'selected'; ?>>accion</option>
        <option value="romance" class="info" <?php if($producto['categoria'] == 'romance') echo 'selected'; ?>>romance</option>
        <option value="shonen"  class="info"<?php if($producto['categoria'] == 'shonen') echo 'selected'; ?>>shonen</option>
        <option value="terror" class="info" <?php if($producto['categoria'] == 'terror') echo 'selected'; ?>>terror</option>
    </select>
    <input type="file" name="imagen" accept="image/*"> <!-- Campo opcional para subir una nueva imagen -->
    <button type="submit" class="edit">Actualizar Producto</button>
</form>

</body>
</html>
