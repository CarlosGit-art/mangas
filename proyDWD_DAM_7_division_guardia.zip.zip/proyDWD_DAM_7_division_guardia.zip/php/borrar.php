<?php
include('../sql/conexion.php');
$id = $_POST['id'];
$sql = "DELETE FROM mangas WHERE id=".$id;
$resultado = mysqli_query($conexion, $sql);
    header("Location: guardarreserva.php");
?>