<?php
 include('../sql/conexion.php');
 $nombre_usuario = $_POST['nombre_usuario'];
 $contrasenia = $_POST['contrasenia'];
 $contraencriptada = md5($contrasenia);
 $sql = "SELECT * FROM usuarios WHERE nombre_usuario = '$nombre_usuario' AND contrasenia = '$contraencriptada'";
 $resultado= mysqli_query($conexion,$sql);
 $datos= mysqli_fetch_assoc($resultado);
 if ($datos['contrasenia'] ==$contraencriptada) {
    //igualamos la contraseña y pedimos los datos y los dirigimos al index del sitio
    session_start();
    $_SESSION['id'] = $datos['id'];
    $_SESSION['nombre_usuario'] = $datos['nombre_usuario'];
    $_SESSION['email'] = $datos['email'];
    $_SESSION['tipo_usuario'] = $datos['tipo_usuario'];
    $_SESSION['carrito'] = array();
    header("Location:index.php");
 }else{
    echo "contraseña incorrecta";
    echo "<a href='iniciosesion.php'>Volver a intentar</a>";
 }

?>