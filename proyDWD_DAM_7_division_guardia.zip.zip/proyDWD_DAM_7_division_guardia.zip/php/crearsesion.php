<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Cuenta</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<?php
 include('../sql/conexion.php');
  //abajo del conexion php creamos una nueva cuenta en la cual se almacena la información del usuario nuevo
 ?>
  <header>
    <img src='../imagenes/fire.png' id='logo'>
    </header>
    <div class="login-container">
        <h2>Crear Cuenta</h2>
        <form action="crear.php" method="post">
        <input type="hidden" id="id" name="id">
            <label for="username">Nombre de Usuario:</label>
            <input type="text" id="nombre_usuario" name="nombre_usuario" required>
            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email" required>  
            <label for="password">Contraseña:</label>
            <input type="password" id="contrasenia" name="contrasenia" required>
            <label for="confirm-password">Confirmar Contraseña:</label>
            <input type="password" id="contrasenia" name="contrasenia" required>
            <button type="submit">Crear Cuenta</button>
        </form>
    </div>
</body>
</html>