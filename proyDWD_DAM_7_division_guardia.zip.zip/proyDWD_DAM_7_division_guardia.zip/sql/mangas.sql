-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-11-2024 a las 09:48:19
-- Versión del servidor: 10.4.18-MariaDB
-- Versión de PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `mangas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mangacomprados`
--

CREATE TABLE `mangacomprados` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `manga_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `mangacomprados`
--

INSERT INTO `mangacomprados` (`id`, `usuario_id`, `manga_id`, `cantidad`, `fecha`) VALUES
(1, 12, 6, 2, '2024-11-20 08:08:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mangas`
--

CREATE TABLE `mangas` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `autor` varchar(100) DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `categoria` varchar(100) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `mangas`
--

INSERT INTO `mangas` (`id`, `titulo`, `autor`, `precio`, `stock`, `categoria`, `imagen`) VALUES
(3, 'dragon ball', 'leo', '2000.00', 9, 'accion', '../imagenes/elias y su pollito.jpg'),
(5, 'dragon ball z', 'leo', '4000.00', 32, 'shonen', '../imagenes/fondo_slider.jpg'),
(6, 'dragon ball z kai', 'kishimoto', '5999.00', 61, 'shonen', NULL),
(7, 'naruto', 'kishomto', '5000.00', 55, 'shonen', '../imagenes/pancho.jpg'),
(8, 'aaa', 'bb', '5000.00', 15, 'romance', NULL),
(9, 'SAO', 'pancho', '42000.00', 200, 'terror', '../imagenes/fondo.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `tipo_usuario` int(10) NOT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `contrasenia` varchar(70) NOT NULL,
  `email` varchar(100) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `tipo_usuario`, `nombre_usuario`, `contrasenia`, `email`, `fecha_creacion`) VALUES
(12, 0, 'juan', '202cb962ac59075b964b07152d234b70', 'juan@juan.com', '2024-11-20 07:05:09'),
(13, 1, 'leo', '81dc9bdb52d04dc20036dbd8313ed055', 'leo@123.com', '2024-11-20 07:14:03');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `mangacomprados`
--
ALTER TABLE `mangacomprados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `manga_id` (`manga_id`);

--
-- Indices de la tabla `mangas`
--
ALTER TABLE `mangas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre_usuario` (`nombre_usuario`),
  ADD UNIQUE KEY `contraseña` (`contrasenia`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `mangacomprados`
--
ALTER TABLE `mangacomprados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `mangas`
--
ALTER TABLE `mangas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `mangacomprados`
--
ALTER TABLE `mangacomprados`
  ADD CONSTRAINT `mangacomprados_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `mangacomprados_ibfk_2` FOREIGN KEY (`manga_id`) REFERENCES `mangas` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
