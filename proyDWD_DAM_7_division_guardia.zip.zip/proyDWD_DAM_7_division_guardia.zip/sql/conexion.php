<?php

    $server = "localhost";
    $user = "root";
    $pass = "";
    $db = "mangas";

    $conexion = mysqli_connect($server,$user,$pass,$db);

    if (!$conexion) {
        die("error  " . mysqli_connect_error());
    }

?>
